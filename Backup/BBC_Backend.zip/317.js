(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[317],{

/***/ "./node_modules/@angular/common/locales/extra/en-001.js":
/*!**************************************************************!*\
  !*** ./node_modules/@angular/common/locales/extra/en-001.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/**
 * @license
 * Copyright Google Inc. All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
(function (factory) {
    if ( true && typeof module.exports === "object") {
        var v = factory(null, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (true) {
        !(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__, exports], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
				__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
				(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
    }
})(function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    // THIS CODE IS GENERATED - DO NOT MODIFY
    // See angular/tools/gulp-tasks/cldr/extract.js
    var u = undefined;
    exports.default = [
        [
            ['mi', 'n', 'in the morning', 'in the afternoon', 'in the evening', 'at night'],
            ['midnight', 'noon', 'in the morning', 'in the afternoon', 'in the evening', 'at night'], u
        ],
        [['midnight', 'noon', 'morning', 'afternoon', 'evening', 'night'], u, u],
        [
            '00:00', '12:00', ['06:00', '12:00'], ['12:00', '18:00'], ['18:00', '21:00'],
            ['21:00', '06:00']
        ]
    ];
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW4tMDAxLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcGFja2FnZXMvY29tbW9uL2xvY2FsZXMvZXh0cmEvZW4tMDAxLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7R0FNRzs7Ozs7Ozs7Ozs7O0lBRUgseUNBQXlDO0lBQ3pDLCtDQUErQztJQUUvQyxJQUFNLENBQUMsR0FBRyxTQUFTLENBQUM7SUFFcEIsa0JBQWU7UUFDYjtZQUNFLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxnQkFBZ0IsRUFBRSxrQkFBa0IsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLENBQUM7WUFDL0UsQ0FBQyxVQUFVLEVBQUUsTUFBTSxFQUFFLGdCQUFnQixFQUFFLGtCQUFrQixFQUFFLGdCQUFnQixFQUFFLFVBQVUsQ0FBQyxFQUFFLENBQUM7U0FDNUY7UUFDRCxDQUFDLENBQUMsVUFBVSxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3hFO1lBQ0UsT0FBTyxFQUFFLE9BQU8sRUFBRSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUM7WUFDNUUsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDO1NBQ25CO0tBQ0YsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBHb29nbGUgSW5jLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vYW5ndWxhci5pby9saWNlbnNlXG4gKi9cblxuLy8gVEhJUyBDT0RFIElTIEdFTkVSQVRFRCAtIERPIE5PVCBNT0RJRllcbi8vIFNlZSBhbmd1bGFyL3Rvb2xzL2d1bHAtdGFza3MvY2xkci9leHRyYWN0LmpzXG5cbmNvbnN0IHUgPSB1bmRlZmluZWQ7XG5cbmV4cG9ydCBkZWZhdWx0IFtcbiAgW1xuICAgIFsnbWknLCAnbicsICdpbiB0aGUgbW9ybmluZycsICdpbiB0aGUgYWZ0ZXJub29uJywgJ2luIHRoZSBldmVuaW5nJywgJ2F0IG5pZ2h0J10sXG4gICAgWydtaWRuaWdodCcsICdub29uJywgJ2luIHRoZSBtb3JuaW5nJywgJ2luIHRoZSBhZnRlcm5vb24nLCAnaW4gdGhlIGV2ZW5pbmcnLCAnYXQgbmlnaHQnXSwgdVxuICBdLFxuICBbWydtaWRuaWdodCcsICdub29uJywgJ21vcm5pbmcnLCAnYWZ0ZXJub29uJywgJ2V2ZW5pbmcnLCAnbmlnaHQnXSwgdSwgdV0sXG4gIFtcbiAgICAnMDA6MDAnLCAnMTI6MDAnLCBbJzA2OjAwJywgJzEyOjAwJ10sIFsnMTI6MDAnLCAnMTg6MDAnXSwgWycxODowMCcsICcyMTowMCddLFxuICAgIFsnMjE6MDAnLCAnMDY6MDAnXVxuICBdXG5dO1xuIl19

/***/ })

}]);
//# sourceMappingURL=317.js.map