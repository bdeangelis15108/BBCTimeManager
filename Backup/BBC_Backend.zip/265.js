(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[265],{

/***/ "./node_modules/@angular/common/locales/extra/az-Latn.js":
/*!***************************************************************!*\
  !*** ./node_modules/@angular/common/locales/extra/az-Latn.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/**
 * @license
 * Copyright Google Inc. All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
(function (factory) {
    if ( true && typeof module.exports === "object") {
        var v = factory(null, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (true) {
        !(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__, exports], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
				__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
				(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
    }
})(function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    // THIS CODE IS GENERATED - DO NOT MODIFY
    // See angular/tools/gulp-tasks/cldr/extract.js
    var u = undefined;
    exports.default = [
        [
            ['gecəyarı', 'g', 'sübh', 'səhər', 'gündüz', 'axşamüstü', 'axşam', 'gecə'],
            ['gecəyarı', 'günorta', 'sübh', 'səhər', 'gündüz', 'axşamüstü', 'axşam', 'gecə'], u
        ],
        [
            ['gecəyarı', 'günorta', 'sübh', 'səhər', 'gündüz', 'axşamüstü', 'axşam', 'gecə'],
            u, u
        ],
        [
            '00:00', '12:00', ['04:00', '06:00'], ['06:00', '12:00'], ['12:00', '17:00'],
            ['17:00', '19:00'], ['19:00', '24:00'], ['00:00', '04:00']
        ]
    ];
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXotTGF0bi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3BhY2thZ2VzL2NvbW1vbi9sb2NhbGVzL2V4dHJhL2F6LUxhdG4udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7OztHQU1HOzs7Ozs7Ozs7Ozs7SUFFSCx5Q0FBeUM7SUFDekMsK0NBQStDO0lBRS9DLElBQU0sQ0FBQyxHQUFHLFNBQVMsQ0FBQztJQUVwQixrQkFBZTtRQUNiO1lBQ0UsQ0FBQyxVQUFVLEVBQUUsR0FBRyxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFdBQVcsRUFBRSxPQUFPLEVBQUUsTUFBTSxDQUFDO1lBQzFFLENBQUMsVUFBVSxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsT0FBTyxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUM7U0FDcEY7UUFDRDtZQUNFLENBQUMsVUFBVSxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsT0FBTyxFQUFFLE1BQU0sQ0FBQztZQUNoRixDQUFDLEVBQUUsQ0FBQztTQUNMO1FBQ0Q7WUFDRSxPQUFPLEVBQUUsT0FBTyxFQUFFLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQztZQUM1RSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUM7U0FDM0Q7S0FDRixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEdvb2dsZSBJbmMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbiAqIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgYXQgaHR0cHM6Ly9hbmd1bGFyLmlvL2xpY2Vuc2VcbiAqL1xuXG4vLyBUSElTIENPREUgSVMgR0VORVJBVEVEIC0gRE8gTk9UIE1PRElGWVxuLy8gU2VlIGFuZ3VsYXIvdG9vbHMvZ3VscC10YXNrcy9jbGRyL2V4dHJhY3QuanNcblxuY29uc3QgdSA9IHVuZGVmaW5lZDtcblxuZXhwb3J0IGRlZmF1bHQgW1xuICBbXG4gICAgWydnZWPJmXlhcsSxJywgJ2cnLCAnc8O8YmgnLCAnc8mZaMmZcicsICdnw7xuZMO8eicsICdheMWfYW3DvHN0w7wnLCAnYXjFn2FtJywgJ2dlY8mZJ10sXG4gICAgWydnZWPJmXlhcsSxJywgJ2fDvG5vcnRhJywgJ3PDvGJoJywgJ3PJmWjJmXInLCAnZ8O8bmTDvHonLCAnYXjFn2Ftw7xzdMO8JywgJ2F4xZ9hbScsICdnZWPJmSddLCB1XG4gIF0sXG4gIFtcbiAgICBbJ2dlY8mZeWFyxLEnLCAnZ8O8bm9ydGEnLCAnc8O8YmgnLCAnc8mZaMmZcicsICdnw7xuZMO8eicsICdheMWfYW3DvHN0w7wnLCAnYXjFn2FtJywgJ2dlY8mZJ10sXG4gICAgdSwgdVxuICBdLFxuICBbXG4gICAgJzAwOjAwJywgJzEyOjAwJywgWycwNDowMCcsICcwNjowMCddLCBbJzA2OjAwJywgJzEyOjAwJ10sIFsnMTI6MDAnLCAnMTc6MDAnXSxcbiAgICBbJzE3OjAwJywgJzE5OjAwJ10sIFsnMTk6MDAnLCAnMjQ6MDAnXSwgWycwMDowMCcsICcwNDowMCddXG4gIF1cbl07XG4iXX0=

/***/ })

}]);
//# sourceMappingURL=265.js.map